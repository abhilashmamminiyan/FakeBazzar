import { useContext } from "react";
import CartContext from "../../Contexts/CartContext";


function Cart() {
    const {cart} = useContext(CartContext);
        console.log("cart", cart)
    return ( 
        <div>
            <h2>Cart Items</h2>
            {cart.length === 0 && <p>Cart is empty</p>}
            {cart.map((item)=>(
                <div key={item.id}>
                    <h4>{item.title}</h4>
                    <p>Qty: {item.qty}</p>
                </div>
            ))}
        </div>
     );
}

export default Cart;