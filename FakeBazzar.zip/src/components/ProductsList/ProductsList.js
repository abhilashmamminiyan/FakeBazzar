import { useContext, useEffect, useState } from "react";
import ProductCard from "../ProductCard/ProductCard";
import styles from './ProductList.module.css';  
import FilterContext from "../../Contexts/FilterContext";
import SearchContext from "../../Contexts/SearchContext";
import { Link } from "react-router-dom";

const ProductList = () => {

  const {productList} = useContext(FilterContext);
  const { searchTerm } = useContext(SearchContext);
  const [categories,setCategories] = useState([]);

  const loadCategories = () => {
    fetch('https://fakestoreapi.com/products/categories').then((response) => {
      response.json().then((data) => {
        setCategories(data);
      })
    })
  }

  useEffect(()=>{ loadCategories(); },[]);
    
  const filteredProducts =  productList.filter((prod)=>
    prod.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  return (
    <>
        
        <div className={styles.productContainer}>
        {filteredProducts.map((p) => {
          return (
            <ProductCard product={p} key={p.id} />
        )
        })}
        {
          filteredProducts.length === 0 && (
          <div className={styles.textmuted}><p>No products found</p>
          </div>
        )
        }
      </div>
    </>
  );
};

export default ProductList;