import styles from './Header.module.css';
import {useContext} from 'react';
import { NavLink, Link, useNavigate, useLocation} from 'react-router-dom';
import AuthContext from '../../Contexts/AuthContext';
import SearchContext from '../../Contexts/SearchContext';

function Header() {
    const { user, logout } = useContext(AuthContext);
    const { setSearchTerm } = useContext(SearchContext);
    const navigate = useNavigate();
    const location = useLocation();

    const handleLogout = () => {
        logout();
        navigate("/login");
    };
    return (
        <div className={styles.header}>
            <nav className="navbar navbar-expand-lg bg-body-tertiary">
                <div className="container-fluid">
                    <a className="navbar-brand" href="/">Fake Bazzar</a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item">
                                <NavLink className="nav-link active" aria-current="page" to='/'>Home</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink className="nav-link active" aria-current="page" to="/products">Products</NavLink>
                            </li>
                            <li>
                        <form className="d-flex" role="search">
                            <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" onChange={(e)=> setSearchTerm(e.target.value)} required />
                            <button className="btn btn-outline-success" type="submit">Search</button>
                        </form>
                        </li>
                            <li className="nav-item">
                                <NavLink className="nav-link active" aria-current="page" to="/about">About Us</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink className="nav-link active" aria-current="page" to="/contact">Contact Us</NavLink>
                            </li>
                        
                        <li>
                        <div className="ms-auto">
                            {user ? (
                            <>
                                <span className="me-3">Welcome, {user.username} 👋</span>
                                <button className="btn btn-outline-danger btn-sm" onClick={handleLogout} >
                                Logout
                                </button>
                            </>
                            ) : (
                                location.pathname !== "/login" && (
                                    <Link className="btn btn-outline-primary" to="/login">
                                        Log In
                                    </Link>
                                )
                            )}
                        </div>
                        </li>
                        <li>
                            <a href='/cart'>Cart</a>
                        </li>
                        </ul>
                    </div>
                </div>
            </nav>

        </div>
    );
}

export default Header;