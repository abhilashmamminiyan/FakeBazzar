import styles from './Footer.module.css';
function Footer() {
    return ( 
        <>
        <div className={styles.footer}>
            <a href='/about'>About Us</a>
            <h5>Contact Us</h5>
            <p>© {new Date().getFullYear()} FakeBazzar</p>
            <p style={{ fontSize: "12px", color: "#777" }}>
                404 illustration by{" "}
                <a
                href="https://www.freepik.com"
                target="_blank"
                rel="noreferrer"
                style={{ color: "#777", textDecoration: "none" }}
                >
                Freepik
                </a>
            </p>
        </div>
        </>
     );
}

export default Footer;