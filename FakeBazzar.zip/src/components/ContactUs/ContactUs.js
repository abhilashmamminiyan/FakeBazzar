function ContactUs() {
    return ( 
        <>
        <h1>This is Contact Us page</h1>
        <div> className
        <div>
            <p>Login to get help with your recent orders and issues</p>
        </div>
        <div>
            <a className="btn btn-primary">Log in</a>
        </div>
        </div>
        </>
     );
}

export default ContactUs;